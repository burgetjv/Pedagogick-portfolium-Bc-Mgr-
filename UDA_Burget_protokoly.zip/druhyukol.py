# UDA úkol č. 10
# Napište funkci, která vypíše čísla od  hodnoty n (n je parametr funkce) do 0.
# Datum vytvoření 9. dubna 2024

def cisla_od_n_do_nuly():
    n = int(input("Zadejte hodnotu n: "))
    for i in range(n, -1, -1):
        print(i)

# Zavolání funkce
cisla_od_n_do_nuly()