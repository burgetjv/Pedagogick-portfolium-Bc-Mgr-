#UDA úkol č. 1
#Jsou dána tři nezáporná čísla, která představují délky stran trojúhelníka. Ověřte, zda-li by bylo možné při zadané délce stran zkonstruovat trojúhelník
# Datum vytvoření 5. dubna 2024

def je_trojuhelnik(a, b, c):
    # Podmínky pro konstrukci trojúhelníku
    if a + b > c and a + c > b and b + c > a:
        return True
    else:
        return False

# Vložení délek všech tří stran
strana1 = int(input("Zadej délku první strany: "))
strana2 = int(input("Zadej délku druhé strany: "))
strana3 = int(input("Zadej délku třetí strany: "))

# Ověření, že může vzniknout trojúhelník
if je_trojuhelnik(strana1, strana2, strana3):
    print("Zadané délky stran mohou tvořit trojúhelník.")
else:
    print("Zadané délky stran nemohou tvořit trojúhelník.")